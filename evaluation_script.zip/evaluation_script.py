import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

def evaluate(test_data, submission):
    # Load the ground truth labels
    ground_truth = pd.read_csv(test_data)
    submission = pd.read_csv(submission)
    
    # Extract true labels and predicted labels
    y_true = ground_truth.iloc[:, -1].values  # Assuming the last column is the label
    y_pred = submission.iloc[:, -1].values  # Assuming the submission file has the predictions in the last column
    
    # Calculate metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    
    # Return the results
    result = {
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1 Score": f1
    }
    return result

if __name__ == "__main__":
    import json
    import os
    import sys
    
    # Paths to the test data and the submission file
    test_data = sys.argv[1]
    submission = sys.argv[2]
    
    # Evaluate the submission
    results = evaluate(test_data, submission)
    
    # Print the results in the required format
    print(json.dumps(results))
